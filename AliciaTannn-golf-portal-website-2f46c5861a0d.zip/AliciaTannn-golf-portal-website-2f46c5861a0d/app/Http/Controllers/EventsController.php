<?php

namespace App\Http\Controllers;

use App\Events;
use Illuminate\Http\Request;

class EventsController extends Controller
{
   public function index() 
   {
    $events = Events::all();
    $events = Events::orderBy('id','desc')->paginate(5);
    return view('events')->with('events', $events); 
   }
}
