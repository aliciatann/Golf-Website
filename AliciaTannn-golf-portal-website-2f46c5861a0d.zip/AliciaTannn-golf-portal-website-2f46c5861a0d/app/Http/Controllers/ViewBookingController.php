<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ViewBookingController extends Controller
{
    public function index() 
    {
        return view('viewbooking');
    }
}
