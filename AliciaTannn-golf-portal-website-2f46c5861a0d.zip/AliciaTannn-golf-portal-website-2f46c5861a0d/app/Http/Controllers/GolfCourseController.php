<?php

namespace App\Http\Controllers;

use App\GolfCourse;
use Illuminate\Http\Request;

class GolfCourseController extends Controller
{
    public function index()
    {
        $golfcourses = GolfCourse::all();
        $golfcourses = GolfCourse::orderBy('id','desc')->paginate(6);
        return view('golfcourses')->with('golfcourses', $golfcourses); 
    }
}
