<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Blog Page</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="all,follow">
    <!-- Price Slider Stylesheets -->
    <link rel="stylesheet" href="vendor/nouislider/nouislider.css">
    <!-- Google fonts - Playfair Display-->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Playfair+Display:400,400i,700">
    <!-- Google fonts - Poppins-->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:300,400,400i,700">
    <!-- swiper-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Swiper/4.4.1/css/swiper.min.css">
    <!-- Magnigic Popup-->
    <link rel="stylesheet" href="vendor/magnific-popup/magnific-popup.css">
    <!-- theme stylesheet-->
    <link rel="stylesheet" href="css/style.default.css" id="theme-stylesheet">
    <!-- Custom stylesheet - for your changes-->
    <link rel="stylesheet" href="css/custom.css">
    <!-- Favicon-->
    <link rel="shortcut icon" href="img/golf.png">
    <!-- Tweaks for older IEs--><!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
    <!-- Font Awesome CSS-->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
  </head>
  <body style="padding-top: 72px;">
    <header class="header">
      <!-- Navbar-->
      <nav class="navbar navbar-expand-lg fixed-top shadow navbar-light bg-white">
        <div class="container-fluid">
          <div class="d-flex align-items-center"><a href="index.html" class="navbar-brand py-1"><img src="img/golf.png" alt="Golf logo"></a>
            <form action="#" id="search" class="form-inline d-none d-sm-flex">
              <div class="input-label-absolute input-label-absolute-left input-reset input-expand ml-lg-2 ml-xl-3"> 
                <label for="search_search" class="label-absolute"><i class="fa fa-search"></i><span class="sr-only">What are you looking for?</span></label>
                <input id="search_search" placeholder="Search" aria-label="Search" class="form-control form-control-sm border-0 shadow-0 bg-gray-200">
                <button type="reset" class="btn btn-reset btn-sm"><i class="fa-times fas"></i></button>
              </div>
            </form>
          </div>
          <button type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation" class="navbar-toggler navbar-toggler-right"><i class="fa fa-bars"></i></button>
          <!-- Navbar Collapse -->
          <div id="navbarCollapse" class="collapse navbar-collapse">
            <form action="#" id="searchcollapsed" class="form-inline mt-4 mb-2 d-sm-none">
              <div class="input-label-absolute input-label-absolute-left input-reset w-100">
                <label for="searchcollapsed_search" class="label-absolute"><i class="fa fa-search"></i><span class="sr-only">What are you looking for?</span></label>
                <input id="searchcollapsed_search" placeholder="Search" aria-label="Search" class="form-control form-control-sm border-0 shadow-0 bg-gray-200">
                <button type="reset" class="btn btn-reset btn-sm"><i class="fa-times fas">           </i></button>
              </div>
            </form>
            
            <ul class="navbar-nav ml-auto">
              <li class="nav-item"><a href="{{ route('home') }}" class="nav-link">Home</a></li>
              <li class="nav-item"><a href="{{ route('golfcourses') }}" class="nav-link">Book Golf Course</a></li>
              <li class="nav-item dropdown"><a id="homeDropdownMenuLink" href="index.html" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="nav-link dropdown-toggle ">
                  Golf Info</a>
                <div aria-labelledby="homeDropdownMenuLink" class="dropdown-menu"><a href="events" class="dropdown-item">Events & Tournaments</a><a href="profile" class="dropdown-item">Golfers</a><a href="blog" class="dropdown-item">Blog</a>
                </div>
              </li>
              <li class="nav-item"><a href="advertising" class="nav-link">Advertising</a></li>
              <li class="nav-item"><a href="contact" class="nav-link">Contact Us</a></li>
              <li class="nav-item"><a href="{{ route('login') }}" class="nav-link">Sign in</a></li>
              <li class="nav-item"><a href="{{ route('register') }}" class="nav-link">Sign up</a></li>
               <li class="nav-item"><a href="{{ route('logout') }}" class="nav-link" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">Logout</a></li>
              <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                        @csrf
                                    </form>
              <li class="nav-item mt-3 mt-lg-0 ml-lg-3 d-lg-none d-xl-inline-block"><a href="{{ route('viewbooking') }}" class="btn btn-primary">View Booking</a></li>
            </ul>  
          </div>
        </div>
      </nav>
      <!-- /Navbar -->
    </header>
    <section class="position-relative py-6"><img src="img/photo/golfWallpaper.jpg" alt="" class="bg-image">
      <div class="container">
        <div class="row">
          <div class="col-lg-6">
            <div class="bg-white rounded-lg shadow p-5"><strong class="text-uppercase text-secondary d-inline-block mb-2 text-sm">Featured</strong>
              <h2 class="mb-3">Your Guide To Golf Coaching</h2>
              <p class="text-muted">Are you seeking professional help to get your golf game up and running? Have you heard so much...</p><a href="post.html" class="btn btn-link p-0">Continue reading <i class="fa fa-long-arrow-alt-right"></i></a>
            </div>
          </div>
        </div>
      </div>
    </section>
    <section class="py-6">
      <div class="container">
        <div class="row mb-5">
          <!-- blog item-->
          <div class="col-lg-4 col-sm-6 mb-4 hover-animate">
            <div class="card shadow border-0 h-100"><a href="post"><img src="img/photo/golfEquipments.jpg" alt="..." class="img-fluid card-img-top"/></a>
              <div class="card-body"><a href="#" class="text-uppercase text-muted text-sm letter-spacing-2">Equipment </a>
                <h5 class="my-2"><a href="post.html" class="text-dark">The importance of golf bags and designs</a></h5>
                <p class="text-gray-500 text-sm my-3"><i class="far fa-clock mr-2"></i>February 10, 2020</p>
                <p class="my-2 text-muted text-sm">In golf, there are a few accessories that make a lot of difference. The club is one thing for sure because it is the tool that gives...</p><a href="post.html" class="btn btn-link pl-0">Read more<i class="fa fa-long-arrow-alt-right ml-2"></i></a>
              </div>
            </div>
          </div>
          <!-- blog item-->
          <div class="col-lg-4 col-sm-6 mb-4 hover-animate">
            <div class="card shadow border-0 h-100"><a href="post.html"><img src="img/photo/golfCartBlog.jpg" alt="..." class="img-fluid card-img-top"/></a>
              <div class="card-body"><a href="#" class="text-uppercase text-muted text-sm letter-spacing-2">Equipment </a>
                <h5 class="my-2"><a href="post.html" class="text-dark">Top golf push carts for beginners</a></h5>
                <p class="text-gray-500 text-sm my-3"><i class="far fa-clock mr-2"></i>February 10, 2020</p>
                <p class="my-2 text-muted text-sm">The push cart is an essential part of what you have during a game of golf. While it might not be the most important accessory...</p><a href="post.html" class="btn btn-link pl-0">Read more<i class="fa fa-long-arrow-alt-right ml-2"></i></a>
              </div>
            </div>
          </div>
          <!-- blog item-->
          <div class="col-lg-4 col-sm-6 mb-4 hover-animate">
            <div class="card shadow border-0 h-100"><a href="post.html"><img src="img/photo/golfBall2.jpg" alt="..." class="img-fluid card-img-top"/></a>
              <div class="card-body"><a href="#" class="text-uppercase text-muted text-sm letter-spacing-2">Equipment </a>
                <h5 class="my-2"><a href="post.html" class="text-dark">Most Expensive Golf Balls          </a></h5>
                <p class="text-gray-500 text-sm my-3"><i class="far fa-clock mr-2"></i>January 1, 2020</p>
                <p class="my-2 text-muted text-sm">Playing a serious game of golf means you must be serious about what you play with....</p><a href="post.html" class="btn btn-link pl-0">Read more<i class="fa fa-long-arrow-alt-right ml-2"></i></a>
              </div>
            </div>
          </div>
          <!-- blog item-->
          <div class="col-lg-4 col-sm-6 mb-4 hover-animate">
            <div class="card shadow border-0 h-100"><a href="post.html"><img src="img/photo/golfCourses.jpg" alt="..." class="img-fluid card-img-top"/></a>
              <div class="card-body"><a href="#" class="text-uppercase text-muted text-sm letter-spacing-2">Game Rules </a>
                <h5 class="my-2"><a href="post.html" class="text-dark">New Golf Rules from 2019          </a></h5>
                <p class="text-gray-500 text-sm my-3"><i class="far fa-clock mr-2"></i>June 3, 2019</p>
                <p class="my-2 text-muted text-sm">2019 witnessed one of the most major change to the golf rules in the past 30 years or so...</p><a href="post.html" class="btn btn-link pl-0">Read more<i class="fa fa-long-arrow-alt-right ml-2"></i></a>
              </div>
            </div>
          </div>
          <!-- blog item-->
          <div class="col-lg-4 col-sm-6 mb-4 hover-animate">
            <div class="card shadow border-0 h-100"><a href="post.html"><img src="img/photo/golfDestinations.jpg" alt="..." class="img-fluid card-img-top"/></a>
              <div class="card-body"><a href="#" class="text-uppercase text-muted text-sm letter-spacing-2">Game Rules </a>
                <h5 class="my-2"><a href="post.html" class="text-dark">What Is A Birdie, Eagle And Bogey?         </a></h5>
                <p class="text-gray-500 text-sm my-3"><i class="far fa-clock mr-2"></i>January 16, 2016</p>
                <p class="my-2 text-muted text-sm">In golf, the term eagle and birdie is commonly used. One might be wondering why the use of flyi......</p><a href="post.html" class="btn btn-link pl-0">Read more<i class="fa fa-long-arrow-alt-right ml-2"></i></a>
              </div>
            </div>
          </div>
          <!-- blog item-->
          <div class="col-lg-4 col-sm-6 mb-4 hover-animate">
            <div class="card shadow border-0 h-100"><a href="post.html"><img src="img/photo/golfEvents.jpg" alt="..." class="img-fluid card-img-top"/></a>
              <div class="card-body"><a href="#" class="text-uppercase text-muted text-sm letter-spacing-2">Game Rules </a>
                <h5 class="my-2"><a href="post.html" class="text-dark">Getting out of the sand bunker</a></h5>
                <p class="text-gray-500 text-sm my-3"><i class="far fa-clock mr-2"></i>July 25, 2016</p>
                <p class="my-2 text-muted text-sm">The sand bunker is constantly one of the biggest challenges that a golfer would have. Contrary to popular beliefs, hitting the ball out of the sand bunker is actually....</p><a href="post.html" class="btn btn-link pl-0">Read more<i class="fa fa-long-arrow-alt-right ml-2"></i></a>
              </div>
            </div>
          </div>
        </div>
        <!-- Pagination -->
        <nav aria-label="Blog pagination">
          <ul class="pagination justify-content-between mb-5">
            <li class="page-item"><a href="#" class="page-link text-sm rounded"> <i class="fa fa-chevron-left mr-1"></i>Older posts</a></li>
            <li class="page-item disabled"><a href="#" tabindex="-1" class="page-link text-sm rounded">Newer posts  <i class="fa fa-chevron-right ml-1">                            </i></a></li>
          </ul>
        </nav>
      </div>
    </section>
    <!-- Footer-->
     <footer class="position-relative z-index-10 d-print-none">
      <!-- Main block - menus, subscribe form-->
      <div class="py-6 bg-gray-200 text-muted"> 
        <div class="container">
          <div class="row">
            <div class="col-lg-4 mb-5 mb-lg-0">
              <div class="font-weight-bold text-uppercase text-dark mb-3">Connect With Us</div>
              <ul class="list-inline">
                <li class="list-inline-item"><a href="#" target="_blank" title="twitter" class="text-muted text-hover-primary"><i class="fab fa-twitter"></i></a></li>
                <li class="list-inline-item"><a href="#" target="_blank" title="facebook" class="text-muted text-hover-primary"><i class="fab fa-facebook"></i></a></li>
                <li class="list-inline-item"><a href="#" target="_blank" title="instagram" class="text-muted text-hover-primary"><i class="fab fa-instagram"></i></a></li>
              </ul>
            </div>
            <div class="col-lg-2 col-md-6 mb-5 mb-lg-0">
              <h6 class="text-uppercase text-dark mb-3">Golf Info</h6>
              <ul class="list-unstyled">
                <li><a href="events.html" class="text-muted">Events & Tournaments</a></li>
                <li><a href="profile.html" class="text-muted">Golfers</a></li>
                <li><a href="blog.html" class="text-muted">Blog</a></li>
                <li><a href="advertising.html" class="text-muted">Advertising</a></li>
              </ul>
            </div>
            <div class="col-lg-2 col-md-6 mb-5 mb-lg-0">
              <h6 class="text-uppercase text-dark mb-3">Our Company</h6>
              <ul class="list-unstyled">
                <li><a href="about.html" class="text-muted">About</a></li>
                <li><a href="contact.html" class="text-muted">Contact Us</a></li>
              </ul>
            </div>
            <div class="col-lg-4">
              <h6 class="text-uppercase text-dark mb-3">Daily Offers & Discounts</h6>
              <form action="#" id="newsletter-form">
                <div class="input-group mb-3">
                  <input type="email" placeholder="Your Email Address" aria-label="Your Email Address" class="form-control bg-transparent border-dark border-right-0">
                  <div class="input-group-append">
                    <button type="submit" class="btn btn-outline-dark border-left-0"> <i class="fa fa-paper-plane text-lg"></i></button>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
      <!-- Copyright section of the footer-->
      <div class="py-4 font-weight-light bg-gray-800 text-gray-300">
        <div class="container">
          <div class="row align-items-center">
            <div class="col-md-6 text-center text-md-left">
              <p class="text-sm mb-md-0">&copy; 2019 JPEG.  All rights reserved.</p>
            </div>
          </div>
        </div>
      </div>
    </footer>
    <!-- /Footer end-->
    <!-- JavaScript files-->
    <script>
      // ------------------------------------------------------- //
      //   Inject SVG Sprite - 
      //   see more here 
      //   https://css-tricks.com/ajaxing-svg-sprite/
      // ------------------------------------------------------ //
      function injectSvgSprite(path) {
      
          var ajax = new XMLHttpRequest();
          ajax.open("GET", path, true);
          ajax.send();
          ajax.onload = function(e) {
          var div = document.createElement("div");
          div.className = 'd-none';
          div.innerHTML = ajax.responseText;
          document.body.insertBefore(div, document.body.childNodes[0]);
          }
      }    
      // to avoid CORS issues when viewing using file:// protocol, using the demo URL for the SVG sprite
      // use your own URL in production, please :)
      // https://demo.bootstrapious.com/directory/1-0/icons/orion-svg-sprite.svg
      //- injectSvgSprite('icons/orion-svg-sprite.svg'); 
      injectSvgSprite('https://demo.bootstrapious.com/directory/1-4/icons/orion-svg-sprite.svg'); 
      
    </script>
    <!-- jQuery-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <!-- Bootstrap JS bundle - Bootstrap + PopperJS-->
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- Magnific Popup - Lightbox for the gallery-->
    <script src="vendor/magnific-popup/jquery.magnific-popup.min.js"></script>
    <!-- Smooth scroll-->
    <script src="vendor/smooth-scroll/smooth-scroll.polyfills.min.js"></script>
    <!-- Bootstrap Select-->
    <script src="vendor/bootstrap-select/js/bootstrap-select.min.js"></script>
    <!-- Object Fit Images - Fallback for browsers that don't support object-fit-->
    <script src="vendor/object-fit-images/ofi.min.js"></script>
    <!-- Swiper Carousel                       -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/4.4.1/js/swiper.min.js"></script>
    <script>var basePath = ''</script>
    <!-- Main Theme JS file    -->
    <script src="js/theme.js"></script>
  </body>
</html>