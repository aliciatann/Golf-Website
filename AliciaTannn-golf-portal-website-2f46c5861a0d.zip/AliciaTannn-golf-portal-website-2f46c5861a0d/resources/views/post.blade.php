<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Blog Post</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="all,follow">
    <!-- Price Slider Stylesheets -->
    <link rel="stylesheet" href="vendor/nouislider/nouislider.css">
    <!-- Google fonts - Playfair Display-->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Playfair+Display:400,400i,700">
    <!-- Google fonts - Poppins-->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:300,400,400i,700">
    <!-- swiper-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Swiper/4.4.1/css/swiper.min.css">
    <!-- Magnigic Popup-->
    <link rel="stylesheet" href="vendor/magnific-popup/magnific-popup.css">
    <!-- theme stylesheet-->
    <link rel="stylesheet" href="css/style.default.css" id="theme-stylesheet">
    <!-- Custom stylesheet - for your changes-->
    <link rel="stylesheet" href="css/custom.css">
    <!-- Favicon-->
    <link rel="shortcut icon" href="img/golf.png">
    <!-- Tweaks for older IEs--><!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
    <!-- Font Awesome CSS-->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
  </head>
  <body>
    <header class="header">
      <!-- Navbar-->
      <nav class="navbar navbar-expand-lg fixed-top shadow navbar-light bg-white">
        <div class="container-fluid">
          <div class="d-flex align-items-center"><a href="index.html" class="navbar-brand py-1"><img src="img/golf.png" alt="Directory logo"></a>
            <form action="#" id="search" class="form-inline d-none d-sm-flex">
              <div class="input-label-absolute input-label-absolute-left input-reset input-expand ml-lg-2 ml-xl-3"> 
                <label for="search_search" class="label-absolute"><i class="fa fa-search"></i><span class="sr-only">What are you looking for?</span></label>
                <input id="search_search" placeholder="Search" aria-label="Search" class="form-control form-control-sm border-0 shadow-0 bg-gray-200">
                <button type="reset" class="btn btn-reset btn-sm"><i class="fa-times fas"></i></button>
              </div>
            </form>
          </div>
          <button type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation" class="navbar-toggler navbar-toggler-right"><i class="fa fa-bars"></i></button>
          <!-- Navbar Collapse -->
          <div id="navbarCollapse" class="collapse navbar-collapse">
            <form action="#" id="searchcollapsed" class="form-inline mt-4 mb-2 d-sm-none">
              <div class="input-label-absolute input-label-absolute-left input-reset w-100">
                <label for="searchcollapsed_search" class="label-absolute"><i class="fa fa-search"></i><span class="sr-only">What are you looking for?</span></label>
                <input id="searchcollapsed_search" placeholder="Search" aria-label="Search" class="form-control form-control-sm border-0 shadow-0 bg-gray-200">
                <button type="reset" class="btn btn-reset btn-sm"><i class="fa-times fas">           </i></button>
              </div>
            </form>
            <ul class="navbar-nav ml-auto">
              <li class="nav-item"><a href="index.html" class="nav-link">Home</a></li>
              <li class="nav-item"><a href="booking.html" class="nav-link">Book Golf Course</a></li>
              <li class="nav-item dropdown"><a id="homeDropdownMenuLink" href="index.html" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="nav-link dropdown-toggle ">
                  Golf Info</a>
                <div aria-labelledby="homeDropdownMenuLink" class="dropdown-menu"><a href="events" class="dropdown-item">Events & Tournaments</a><a href="profile" class="dropdown-item">Golfers</a><a href="blog" class="dropdown-item">Blog</a>
                </div>
              </li>
              <li class="nav-item"><a href="#" class="nav-link">Advertising</a></li>
              <li class="nav-item"><a href="#" class="nav-link">Contact Us</a></li>
              <li class="nav-item"><a href="#" class="nav-link">Sign in</a></li>
              <li class="nav-item"><a href="#" class="nav-link">Sign up</a></li>
               <li class="nav-item"><a href="#" class="nav-link" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">Logout</a></li>
              <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                        @csrf
                                    </form>
              <li class="nav-item mt-3 mt-lg-0 ml-lg-3 d-lg-none d-xl-inline-block"><a href="{{ route('viewbooking') }}" class="btn btn-primary">View Booking</a></li>
            </ul>  
          </div>
        </div>
      </nav>
      <!-- /Navbar -->
    </header>
    <section class="hero-home dark-overlay mb-5"><img src="img/photo/banner3.jpg" alt="" class="bg-image">
      <div class="container py-7">
        <div class="overlay-content text-center text-white">
          <h1 class="display-3 text-serif font-weight-bold text-shadow mb-0">The importance of golf bags and designs</h1>
        </div>
      </div>
    </section>
    <section>
      <div class="container">
        <div class="row">
          <div class="col-xl-8 col-lg-10 mx-auto">           
            <p class="py-3 mb-5 text-muted text-center font-weight-light"><a href=""><img src="img/avatar/account.png" alt="" class="avatar mr-2"></a> Written by <a href="#" class="font-weight-bold">Alexandra</a><span class="mx-1">|</span> February 10, 2020 in <a href="blog" class="font-weight-bold">Equipments</a><span class="mx-1">|</span><a href="#" class="text-muted">2 comments                </a></p>
            <p class="lead mb-5">In golf, there are a few accessories that make a lot of difference. The club is one thing for sure because it is the tool that gives your game the quality it needs. And then there is the apparel like the shirt you wear and the cap you use or even the gloves on your hands. But one accessory which is often overlooked is the golf bag which a lot of golfer like to think that it is only for storage purposes.</p>
          </div>
        </div>
        <div class="row">
          <div class="col-xl-8 mx-auto"><img src="img/photo/golfEquipments.jpg" alt="" class="img-fluid mb-5"></div>
        </div>
        <div class="row">
          <div class="col-xl-8 col-lg-10 mx-auto">                               
            <div class="text-content">
              <h3>Just a bag?</h3>
              <p>It must be noted that golf bags are not ‘just bags’. They play a much more important role than you can imagine. In fact, it is often seen as your personal companion and in some cases, reflecting your personality. You will always be seen with different clubs all the time whether you are driving or putting but it is the bag that is always with you. It is who you are and, in many ways, what you are. Before you buy a bag, there are several factors that you must consider. Among them include:</p>
              <ul>
                <li><strong>Design</strong> – The look and feel of it. What do you want to be associated with in terms of style and design?</li>
                <li><strong>Functionality</strong> – Take note that the golf bag is not one that you just chuck everything in. Each compartment has its own functions and you need to know what they do.</li>
                <li><strong>Extras</strong> – Are there compartments that are there not only for the clubs? Do you usually put an umbrella or rangefinders? Are there pockets for them and do you actually need these pockets? Some golfers prefer to bring a separate bag but having these in your golf bag might make it a lot more convenient.</li>
              </ul>
              <h3>Types of golf bags</h3>
              <p>So, here we go with the various types of golf bags you can get to play your game with. Yes! They have specific names to them, and here they are!</p>
              <ul>
                <li><strong>Staff Bags</strong> – This is perhaps the most common type of bag you will notice golfers having them around. They have a large logo on shown and they are the usual ones that tell people who they are. Staff bags are big and loud. They are heavy too but since they are used a lot by pros, there are caddies who will carry these bags. The main features of staff bags: lots of space, high quality, looks really good!</li>
                <li><strong>Cart Bags</strong> – These bags usually weigh around 10 to 15 kgs. They are smaller than the staff bags and they are designed to be carried on your bag or being pushed on using a cart. Cart bags are an absolute NO-NO if you are playing on a walking course. In terms of quality, cart bags are not as good but they are durable. Cart bags are great for convenience.</li>
                <li><strong>Stand Bags</strong> – These bags are smaller and lighter. They are designed for golfers who are on a walking course. In fact, the designs are such that it makes walking easier. They come with 2 retractable legs so that the bag can ‘stand’ on its own. They can be upright or canted so that the golfer can get to the clubs easier. Unlike staff or cart bags, stand bags can be used very much on any surfaces whether they are flat or not. Most of the stand bags come with shoulder straps for easy carriage. In some cases, they can be attached to a cart if needed.</li>
              </ul>
            </div>
            <!-- comments-->
            <div class="mt-5">
              <h6 class="text-uppercase text-muted mb-4">2 comments</h6>
              <!-- comment-->
              <div class="media mb-4"><img src="img/avatar/avatar-0.jpg" alt="Julie Alma" class="avatar avatar-lg mr-4">
                <div class="media-body">
                  <h5>Nur Julina</h5>
                  <p class="text-uppercase text-sm text-muted"><i class="far fa-clock"></i> September 23, 2020 at 12:00 am</p>
                  <p class="text-muted">Very useful articles on golf bags</p>
                  <p><a href="#" class="btn btn-link text-primary"><i class="fa fa-reply"></i> Reply</a></p>
                </div>
              </div>
              <!-- /comment-->
              <!-- comment-->
              <div class="media mb-4"><img src="img/avatar/avatar-8.jpg" alt="Louise Armero" class="avatar avatar-lg mr-4">
                <div class="media-body">
                  <h5>Dana Lynn</h5>
                  <p class="text-uppercase text-sm text-muted"><i class="far fa-clock"></i> June 23, 2017 at 12:35 pm</p>
                  <p class="text-muted">A lot of informations of golf bags</p>
                  <p><a href="#" class="btn btn-link text-primary"><i class="fa fa-reply"></i> Reply</a></p>
                </div>
              </div>
              <!-- /comment-->
            </div>
            <!-- /comments-->
            
            <!-- comment form-->
            <div class="mb-5">
              <button type="button" data-toggle="collapse" data-target="#leaveComment" aria-expanded="false" aria-controls="leaveComment" class="btn btn-outline-primary">Leave a comment</button>
              <div id="leaveComment" class="collapse mt-4">
                <h5 class="mb-4">Leave a comment</h5>
                <form id="comment-form" method="post" action="#" class="form">
                  <div class="row">
                    <div class="col-md-6">                           
                      <div class="form-group">
                        <label for="name" class="form-label">Name <span class="required">*</span></label>
                        <input id="name" type="text" class="form-control">
                      </div>
                    </div>
                    <div class="col-md-6">                                              
                      <div class="form-group">
                        <label for="email" class="form-label">Email <span class="required">*</span></label>
                        <input id="email" type="text" class="form-control">
                      </div>
                    </div>
                  </div>
                  <div class="form-group mb-4">
                    <label for="comment" class="form-label">Comment <span class="required">*</span></label>
                    <textarea id="comment" rows="4" class="form-control"></textarea>
                  </div>
                  <button type="submit" class="btn btn-primary"><i class="far fa-comment"></i> Comment                                   </button>
                </form>
              </div>
            </div>
            <!-- /comment form-->
          </div>
        </div>
      </div>
    </section>
    <!-- Footer-->
     <footer class="position-relative z-index-10 d-print-none">
      <!-- Main block - menus, subscribe form-->
      <div class="py-6 bg-gray-200 text-muted"> 
        <div class="container">
          <div class="row">
            <div class="col-lg-4 mb-5 mb-lg-0">
              <div class="font-weight-bold text-uppercase text-dark mb-3">Connect With Us</div>
              <ul class="list-inline">
                <li class="list-inline-item"><a href="#" target="_blank" title="twitter" class="text-muted text-hover-primary"><i class="fab fa-twitter"></i></a></li>
                <li class="list-inline-item"><a href="#" target="_blank" title="facebook" class="text-muted text-hover-primary"><i class="fab fa-facebook"></i></a></li>
                <li class="list-inline-item"><a href="#" target="_blank" title="instagram" class="text-muted text-hover-primary"><i class="fab fa-instagram"></i></a></li>
              </ul>
            </div>
            <div class="col-lg-2 col-md-6 mb-5 mb-lg-0">
              <h6 class="text-uppercase text-dark mb-3">Golf Info</h6>
              <ul class="list-unstyled">
                <li><a href="events.html" class="text-muted">Events & Tournaments</a></li>
                <li><a href="profile.html" class="text-muted">Golfers</a></li>
                <li><a href="blog.html" class="text-muted">Blog</a></li>
                <li><a href="advertising.html" class="text-muted">Advertising</a></li>
              </ul>
            </div>
            <div class="col-lg-2 col-md-6 mb-5 mb-lg-0">
              <h6 class="text-uppercase text-dark mb-3">Our Company</h6>
              <ul class="list-unstyled">
                <li><a href="about.html" class="text-muted">About</a></li>
                <li><a href="contact.html" class="text-muted">Contact Us</a></li>
              </ul>
            </div>
            <div class="col-lg-4">
              <h6 class="text-uppercase text-dark mb-3">Daily Offers & Discounts</h6>
              <form action="#" id="newsletter-form">
                <div class="input-group mb-3">
                  <input type="email" placeholder="Your Email Address" aria-label="Your Email Address" class="form-control bg-transparent border-dark border-right-0">
                  <div class="input-group-append">
                    <button type="submit" class="btn btn-outline-dark border-left-0"> <i class="fa fa-paper-plane text-lg"></i></button>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
      <!-- Copyright section of the footer-->
      <div class="py-4 font-weight-light bg-gray-800 text-gray-300">
        <div class="container">
          <div class="row align-items-center">
            <div class="col-md-6 text-center text-md-left">
              <p class="text-sm mb-md-0">&copy; 2019 JPEG.  All rights reserved.</p>
            </div>
          </div>
        </div>
      </div>
    </footer>
    <!-- /Footer end-->
    <!-- JavaScript files-->
    <script>
      // ------------------------------------------------------- //
      //   Inject SVG Sprite - 
      //   see more here 
      //   https://css-tricks.com/ajaxing-svg-sprite/
      // ------------------------------------------------------ //
      function injectSvgSprite(path) {
      
          var ajax = new XMLHttpRequest();
          ajax.open("GET", path, true);
          ajax.send();
          ajax.onload = function(e) {
          var div = document.createElement("div");
          div.className = 'd-none';
          div.innerHTML = ajax.responseText;
          document.body.insertBefore(div, document.body.childNodes[0]);
          }
      }    
      // to avoid CORS issues when viewing using file:// protocol, using the demo URL for the SVG sprite
      // use your own URL in production, please :)
      // https://demo.bootstrapious.com/directory/1-0/icons/orion-svg-sprite.svg
      //- injectSvgSprite('icons/orion-svg-sprite.svg'); 
      injectSvgSprite('https://demo.bootstrapious.com/directory/1-4/icons/orion-svg-sprite.svg'); 
      
    </script>
    <!-- jQuery-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <!-- Bootstrap JS bundle - Bootstrap + PopperJS-->
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- Magnific Popup - Lightbox for the gallery-->
    <script src="vendor/magnific-popup/jquery.magnific-popup.min.js"></script>
    <!-- Smooth scroll-->
    <script src="vendor/smooth-scroll/smooth-scroll.polyfills.min.js"></script>
    <!-- Bootstrap Select-->
    <script src="vendor/bootstrap-select/js/bootstrap-select.min.js"></script>
    <!-- Object Fit Images - Fallback for browsers that don't support object-fit-->
    <script src="vendor/object-fit-images/ofi.min.js"></script>
    <!-- Swiper Carousel                       -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/4.4.1/js/swiper.min.js"></script>
    <script>var basePath = ''</script>
    <!-- Main Theme JS file    -->
    <script src="js/theme.js"></script>
  </body>
</html>